class Contact < ApplicationRecord
  validates :contents, length: {minimum: 1}
  validates :contents, length: {maximum: 140}
end
