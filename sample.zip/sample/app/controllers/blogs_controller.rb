class BlogsController < ApplicationController
  def index
    @blogs = Blog.all
    #added for debugging
    #binding.pry
    #raise
  end

  def new
    #Added
    @blog = Blog.new
  end
  #Added
  def create
    #Blog.create(title:params[:blog][:title],content:params[:blog][:content])
    #Blog.create(params.require(:blog).permit(:title, :content))
    Blog.create(blog_params)
    redirect_to new_blog_path
  end

  def create
      @blog = Blog.new(blog_params)
      if @blog.save
        # Switch to the list screen and display a message saying "You have created new blog!"
        redirect_to blogs_path, notice: "You have created new blog!"
      else
        # Redraw the input form.
        render :new
      end
    end

#define

def show
  #Added
  @blog = Blog.find(params[:id])
end

#added for editing purposes

def edit
  @blog = Blog.find(params[:id])
end

def update
  @blog = Blog.find(params[:id])

  if @blog.update(blog_params)
    redirect_to blogs_path, notice: "You have edited this blog!"
  else
    render :edit
  end
end

  private
  def blog_params
    params.require(:blog).permit(:title, :content)
  end
end
